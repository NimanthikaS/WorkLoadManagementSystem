-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2023 at 02:32 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `workloadmanagementsystem`
--
CREATE DATABASE IF NOT EXISTS `workloadmanagementsystem` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `workloadmanagementsystem`;

-- --------------------------------------------------------

--
-- Table structure for table `3rd_year_group_project`
--

CREATE TABLE `3rd_year_group_project` (
  `EmployeeID` varchar(20) NOT NULL,
  `GPNo` int(11) NOT NULL,
  `GroupNo` int(11) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `ProjectTitle` varchar(250) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `noOfStudents` int(11) NOT NULL,
  `EvolutionTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `3rd_year_group_project`
--

INSERT INTO `3rd_year_group_project` (`EmployeeID`, `GPNo`, `GroupNo`, `CourseCode`, `ProjectTitle`, `StartDate`, `EndDate`, `noOfStudents`, `EvolutionTime`, `Academic_year`, `is_deleted`) VALUES
('ASM/DPS/001', 1, 2, 'IT3162', 'Work Load Management System', '2023-06-30', '2023-11-19', 55, 825, '2018/19', 0),
('ASM/DPS/001', 2, 9, 'IT3162', 'Information Management System', '2023-06-24', '2023-10-10', 85, 1275, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `4th_year_research`
--

CREATE TABLE `4th_year_research` (
  `EmployeeID` varchar(20) NOT NULL,
  `ResNo` int(11) NOT NULL,
  `RegNo` varchar(10) NOT NULL,
  `StudentName` varchar(100) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `ResearchTitle` varchar(250) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `EvolutionTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `4th_year_research`
--

INSERT INTO `4th_year_research` (`EmployeeID`, `ResNo`, `RegNo`, `StudentName`, `CourseCode`, `ResearchTitle`, `StartDate`, `EndDate`, `EvolutionTime`, `Academic_year`, `is_deleted`) VALUES
('ASM/DPS/001', 1, '2018ICT21', 'W.A.N.S. Dayarathna', 'IT4112', 'Under water communication', '2023-06-16', '2024-05-09', 30, '2018/19', 0),
('ASM/DPS/001', 2, '2018ICT22', 'R. Praneetha', 'IT4162', 'Medical Image Processing system', '2023-06-24', '2024-04-10', 30, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `academicyear`
--

CREATE TABLE `academicyear` (
  `AccNo` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academicyear`
--

INSERT INTO `academicyear` (`AccNo`, `Academic_year`) VALUES
(1, '2018/19'),
(2, '2017/18');

-- --------------------------------------------------------

--
-- Table structure for table `academic_cor`
--

CREATE TABLE `academic_cor` (
  `EmployeeID` varchar(50) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `direct_PGS` int(11) NOT NULL,
  `aca_advis` int(11) NOT NULL,
  `per_men` int(11) NOT NULL,
  `stu_cor` int(11) NOT NULL,
  `aca_coor` int(11) NOT NULL,
  `research_p` int(11) NOT NULL,
  `aca_sub_coor` int(11) NOT NULL,
  `aca_eve_coor` int(11) NOT NULL,
  `new_degree` int(11) NOT NULL,
  `new_course` int(11) NOT NULL,
  `resour_per` int(11) NOT NULL,
  `infra_dev` int(11) NOT NULL,
  `meeting` int(11) NOT NULL,
  `stu_advi_board` int(11) NOT NULL,
  `board_of_stu` int(11) NOT NULL,
  `VC_DVC` int(11) NOT NULL,
  `dean` int(11) NOT NULL,
  `proctor` int(11) NOT NULL,
  `stu_counce` int(11) NOT NULL,
  `coordinator` int(11) NOT NULL,
  `senior_tresh` int(11) NOT NULL,
  `advi_ndp` int(11) NOT NULL,
  `country_rep` int(11) NOT NULL,
  `outreach_act` int(11) NOT NULL,
  `coor_confere` int(11) NOT NULL,
  `serving_office` int(11) NOT NULL,
  `proffesional_dev` int(11) NOT NULL,
  `staff_dev` int(11) NOT NULL,
  `advance_prof` int(11) NOT NULL,
  `TEC` int(11) NOT NULL,
  `other` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_cor`
--

INSERT INTO `academic_cor` (`EmployeeID`, `Academic_year`, `direct_PGS`, `aca_advis`, `per_men`, `stu_cor`, `aca_coor`, `research_p`, `aca_sub_coor`, `aca_eve_coor`, `new_degree`, `new_course`, `resour_per`, `infra_dev`, `meeting`, `stu_advi_board`, `board_of_stu`, `VC_DVC`, `dean`, `proctor`, `stu_counce`, `coordinator`, `senior_tresh`, `advi_ndp`, `country_rep`, `outreach_act`, `coor_confere`, `serving_office`, `proffesional_dev`, `staff_dev`, `advance_prof`, `TEC`, `other`) VALUES
('ASM/DPS/001', '2017/18', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('ASM/DPS/001', '2018/19', 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 0, 400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `academic_instructions_practical_lecture_sessions`
--

CREATE TABLE `academic_instructions_practical_lecture_sessions` (
  `CNo` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `Year` int(20) NOT NULL,
  `Semester` int(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `ActualLectureTime` float NOT NULL,
  `PreperationTimeOfPracticalSessions` float NOT NULL,
  `creditTime` float NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_instructions_practical_lecture_sessions`
--

INSERT INTO `academic_instructions_practical_lecture_sessions` (`CNo`, `EmployeeID`, `Year`, `Semester`, `CourseCode`, `NumberOfCredits`, `NumberOfStudents`, `ActualLectureTime`, `PreperationTimeOfPracticalSessions`, `creditTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 2, 1, 'IT2153', 1, 123, 24, 60, 30, '2018/19', 0),
(2, 'ASM/DPS/001', 2, 1, 'CSC2113', 1, 55, 34, 85, 30, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `academic_instructions_theory_lecture_sessions`
--

CREATE TABLE `academic_instructions_theory_lecture_sessions` (
  `TNo` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `Year` int(20) NOT NULL,
  `Semester` int(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `ActualLectureTime` float NOT NULL,
  `creditTime` float NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `quiz_ass_tu` float NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_instructions_theory_lecture_sessions`
--

INSERT INTO `academic_instructions_theory_lecture_sessions` (`TNo`, `EmployeeID`, `Year`, `Semester`, `CourseCode`, `NumberOfCredits`, `NumberOfStudents`, `ActualLectureTime`, `creditTime`, `Academic_year`, `quiz_ass_tu`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 1, 1, 'CSC1123', 2, 85, 34, 30, '2017/18', 137.6, 0),
(2, 'ASM/DPS/001', 3, 1, 'AMA3113', 3, 55, 34, 45, '2017/18', 172.4, 0),
(3, 'ASM/DPS/001', 2, 1, 'IT2153', 2, 123, 34, 30, '2018/19', 151.2, 0),
(4, 'ASM/DPS/001', 4, 2, 'CSH4162', 2, 13, 30, 30, '2018/19', 120, 0),
(5, 'ASM/DPS/001', 3, 2, 'AMA3213', 3, 55, 34, 45, '2018/19', 172.4, 0),
(6, 'ASM/DPS/001', 2, 1, 'IT2153', 2, 45, 30, 30, '2018/19', 120, 1),
(7, 'ASM/DPS/001', 3, 1, 'ACU3112', 2, 123, 24, 30, '2018/19', 133.2, 0),
(8, 'ASM/DPS/001', 1, 2, 'AMA1213', 3, 123, 24, 45, '2018/19', 178.2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `computation_results`
--

CREATE TABLE `computation_results` (
  `CRN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `TheoryPractical` varchar(10) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `computation_results`
--

INSERT INTO `computation_results` (`CRN`, `EmployeeID`, `CourseCode`, `TheoryPractical`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'IT1114', 'practical', 83, 8, '2018/19', 0),
(2, 'ASM/DPS/001', 'IT1113', 'theory', 50, 5, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `evolution_practical_reports`
--

CREATE TABLE `evolution_practical_reports` (
  `EPR` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evolution_practical_reports`
--

INSERT INTO `evolution_practical_reports` (`EPR`, `EmployeeID`, `CourseCode`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'IT1144', 80, 13, '2018/19', 0),
(2, 'ASM/DPS/001', 'IT1115', 80, 13, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `evolution_quiz_assignments_tutorials`
--

CREATE TABLE `evolution_quiz_assignments_tutorials` (
  `EQN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `TheoryPractical` varchar(10) NOT NULL,
  `NumberOfAss` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evolution_quiz_assignments_tutorials`
--

INSERT INTO `evolution_quiz_assignments_tutorials` (`EQN`, `EmployeeID`, `CourseCode`, `TheoryPractical`, `NumberOfAss`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'IT2153', 'practical', 5, 123, 103, '2018/19', 0),
(2, 'ASM/DPS/001', 'IT1113', 'practical', 4, 100, 67, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `intern_supervision`
--

CREATE TABLE `intern_supervision` (
  `EmployeeID` varchar(20) NOT NULL,
  `InNo` int(11) NOT NULL,
  `RegNo` varchar(10) NOT NULL,
  `StudentName` varchar(100) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `EvolutionTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `intern_supervision`
--

INSERT INTO `intern_supervision` (`EmployeeID`, `InNo`, `RegNo`, `StudentName`, `CourseCode`, `Position`, `StartDate`, `EndDate`, `EvolutionTime`, `Academic_year`, `is_deleted`) VALUES
('ASM/DPS/001', 1, '2018ICT21', 'W.A.N.S. Dayarathna', 'IT4224', 'QA', '2023-06-24', '2023-10-10', 15, '2018/19', 0),
('ASM/DPS/001', 2, '2018ICT20', 'Suhashi', 'IT4163', 'SE', '2023-06-10', '2023-10-10', 15, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `marking_exam_papers`
--

CREATE TABLE `marking_exam_papers` (
  `Mex` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marking_exam_papers`
--

INSERT INTO `marking_exam_papers` (`Mex`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'CSC1123', 2, 84, 112, '2018/19', 0),
(2, 'ASM/DPS/001', 'CSC1213', 2, 10, 13, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `marking_exam_papersp`
--

CREATE TABLE `marking_exam_papersp` (
  `Mex` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marking_exam_papersp`
--

INSERT INTO `marking_exam_papersp` (`Mex`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'CSC2113', 1, 100, 67, '2018/19', 0),
(2, 'ASM/DPS/001', 'STA3113', 1, 50, 33, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `moderating_exam_papers`
--

CREATE TABLE `moderating_exam_papers` (
  `MEN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `moderating_exam_papers`
--

INSERT INTO `moderating_exam_papers` (`MEN`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'AMA3213', 3, 3, '2018/19', 0),
(2, 'ASM/DPS/001', 'CSC1213', 2, 2, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `moderating_exam_papersp`
--

CREATE TABLE `moderating_exam_papersp` (
  `MEN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `moderating_exam_papersp`
--

INSERT INTO `moderating_exam_papersp` (`MEN`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'CSC2113', 1, 1, '2018/19', 0),
(2, 'ASM/DPS/001', 'CSC3213', 1, 1, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `practical_field_visits`
--

CREATE TABLE `practical_field_visits` (
  `EmployeeID` varchar(20) NOT NULL,
  `FNo` int(11) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `Date` date NOT NULL,
  `Title` varchar(250) NOT NULL,
  `Description` varchar(250) NOT NULL,
  `Number_Of_Students` int(11) NOT NULL,
  `Required_Time` float NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practical_field_visits`
--

INSERT INTO `practical_field_visits` (`EmployeeID`, `FNo`, `CourseCode`, `Date`, `Title`, `Description`, `Number_Of_Students`, `Required_Time`, `Academic_year`, `is_deleted`) VALUES
('ASM/DPS/001', 1, 'ENS1223', '2023-06-15', 'ICA 01', 'ICA 01', 60, 7, '2018/19', 0),
('ASM/DPS/001', 2, 'ENS1222', '2023-06-30', 'Assignment 01', 'residential', 80, 5, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `practical_subjects`
--

CREATE TABLE `practical_subjects` (
  `course_code` varchar(50) NOT NULL,
  `No_of_credits` int(11) NOT NULL,
  `Semester` int(11) NOT NULL,
  `Year_of_study` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practical_subjects`
--

INSERT INTO `practical_subjects` (`course_code`, `No_of_credits`, `Semester`, `Year_of_study`) VALUES
('AMA2113', 1, 1, 2),
('CSC1113', 2, 1, 1),
('CSC1123', 1, 1, 1),
('CSC1213', 1, 2, 1),
('CSC1223', 1, 2, 1),
('CSC2113', 1, 1, 2),
('CSC2234', 1, 2, 2),
('CSC3123', 1, 1, 3),
('CSC3132', 2, 1, 3),
('CSC3213', 1, 2, 3),
('CSH3143', 1, 2, 3),
('CSH3153', 1, 2, 3),
('CSH3254', 1, 2, 3),
('CSH4123', 1, 1, 4),
('CSH4144', 1, 1, 4),
('IT2153', 1, 1, 2),
('STA2113', 1, 1, 2),
('STA3113', 1, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `practical_viva_sessions`
--

CREATE TABLE `practical_viva_sessions` (
  `EmployeeID` varchar(20) NOT NULL,
  `PV_No` int(11) NOT NULL,
  `Course_Code` varchar(10) NOT NULL,
  `Date` date NOT NULL,
  `Title` varchar(250) NOT NULL,
  `Description` varchar(250) NOT NULL,
  `Number_Of_Students` int(11) NOT NULL,
  `Required_Time` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `practical_viva_sessions`
--

INSERT INTO `practical_viva_sessions` (`EmployeeID`, `PV_No`, `Course_Code`, `Date`, `Title`, `Description`, `Number_Of_Students`, `Required_Time`, `Academic_year`, `is_deleted`) VALUES
('ASM/DPS/001', 1, 'IT1113', '2023-06-23', 'ICA02', ' Introduction', 86, 29, '2018/19', 0),
('ASM/DPS/001', 2, 'IT1134', '2023-06-24', 'ICA 01', 'Loops and condition checking', 50, 4, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `research_supervision`
--

CREATE TABLE `research_supervision` (
  `PhD_Full_Time` int(11) NOT NULL,
  `PhD_Part_Time` int(11) NOT NULL,
  `M_Phil_Full_Time` int(11) NOT NULL,
  `MPhil_Part_Time` int(11) NOT NULL,
  `MSc_Full_Time` int(11) NOT NULL,
  `Course_based_MSc_Part_Time` int(11) NOT NULL,
  `Research_projects` int(11) NOT NULL,
  `EmployeeID` varchar(50) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `no_of_research` int(6) NOT NULL,
  `mem_of_rct` int(6) NOT NULL,
  `ref_jour` int(6) NOT NULL,
  `non_ref_jour` int(6) NOT NULL,
  `conference_ppr` int(6) NOT NULL,
  `extended_abs` int(6) NOT NULL,
  `abstract` int(6) NOT NULL,
  `author_of_bk` int(11) NOT NULL,
  `author_chap_of_bk` int(6) NOT NULL,
  `author_monograph` int(6) NOT NULL,
  `author_policyppr` int(6) NOT NULL,
  `author_consultancy_repo` int(6) NOT NULL,
  `soft_dev` int(6) NOT NULL,
  `media_pro` int(6) NOT NULL,
  `translation_pub` int(6) NOT NULL,
  `peer_reviewed` int(6) NOT NULL,
  `Editor` int(6) NOT NULL,
  `co_editor` int(6) NOT NULL,
  `member_editorial` int(6) NOT NULL,
  `chair_national` int(6) NOT NULL,
  `chair_international` int(6) NOT NULL,
  `workshop_cor` int(6) NOT NULL,
  `reviewer` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `research_supervision`
--

INSERT INTO `research_supervision` (`PhD_Full_Time`, `PhD_Part_Time`, `M_Phil_Full_Time`, `MPhil_Part_Time`, `MSc_Full_Time`, `Course_based_MSc_Part_Time`, `Research_projects`, `EmployeeID`, `Academic_year`, `no_of_research`, `mem_of_rct`, `ref_jour`, `non_ref_jour`, `conference_ppr`, `extended_abs`, `abstract`, `author_of_bk`, `author_chap_of_bk`, `author_monograph`, `author_policyppr`, `author_consultancy_repo`, `soft_dev`, `media_pro`, `translation_pub`, `peer_reviewed`, `Editor`, `co_editor`, `member_editorial`, `chair_national`, `chair_international`, `workshop_cor`, `reviewer`) VALUES
(90, 0, 0, 0, 0, 0, 0, 'ASM/DPS/001', '2017/18', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(900, 0, 0, 90, 0, 0, 0, 'ASM/DPS/001', '2018/19', 0, 0, 400, 0, 0, 0, 0, 1600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `seminar_course`
--

CREATE TABLE `seminar_course` (
  `SC_No` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `TheoryPractical` varchar(10) NOT NULL,
  `NumberOfWeeks` int(11) NOT NULL,
  `NumberOfStudents` int(11) NOT NULL,
  `TotalTime` int(11) NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seminar_course`
--

INSERT INTO `seminar_course` (`SC_No`, `EmployeeID`, `CourseCode`, `TheoryPractical`, `NumberOfWeeks`, `NumberOfStudents`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'IT1114', 'practical', 4, 40, 160, '2018/19', 0),
(2, 'ASM/DPS/001', 'IT1112', 'theory', 4, 100, 400, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `setting_exam_papers`
--

CREATE TABLE `setting_exam_papers` (
  `SPN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `ActualTime` float NOT NULL,
  `TotalTime` float NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `setting_exam_papers`
--

INSERT INTO `setting_exam_papers` (`SPN`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `ActualTime`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'AMA2213', 3, 8, 17, '2018/19', 0),
(2, 'ASM/DPS/001', 'CSC1113', 2, 15, 21, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `setting_exam_papers_practical`
--

CREATE TABLE `setting_exam_papers_practical` (
  `SPN` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `NumberOfCredits` int(11) NOT NULL,
  `ActualTime` float NOT NULL,
  `TotalTime` float NOT NULL,
  `Academic_year` varchar(20) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `setting_exam_papers_practical`
--

INSERT INTO `setting_exam_papers_practical` (`SPN`, `EmployeeID`, `CourseCode`, `NumberOfCredits`, `ActualTime`, `TotalTime`, `Academic_year`, `is_deleted`) VALUES
(1, 'ASM/DPS/001', 'CSC1223', 1, 3, 6, '2018/19', 0),
(2, 'ASM/DPS/001', 'IT2153', 1, 15, 18, '2017/18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `theory_subjects`
--

CREATE TABLE `theory_subjects` (
  `course_code` varchar(50) NOT NULL,
  `No_of_credits` int(10) NOT NULL,
  `Semester` int(11) NOT NULL,
  `Year_of_study` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `theory_subjects`
--

INSERT INTO `theory_subjects` (`course_code`, `No_of_credits`, `Semester`, `Year_of_study`) VALUES
('ACU1113', 3, 1, 1),
('ACU2113', 3, 1, 2),
('ACU2212', 2, 2, 2),
('ACU3112', 2, 1, 3),
('ACU3212', 2, 2, 3),
('ACU3222', 2, 2, 3),
('AMA1113', 3, 1, 1),
('AMA1213', 3, 2, 1),
('AMA2113', 2, 1, 2),
('AMA2122', 2, 1, 2),
('AMA2213', 3, 2, 2),
('AMA3113', 3, 1, 3),
('AMA3122', 2, 1, 3),
('AMA3213', 3, 2, 3),
('CSC1113', 2, 1, 1),
('CSC1123', 2, 1, 1),
('CSC1213', 2, 2, 1),
('CSC1223', 2, 2, 1),
('CSC2113', 2, 1, 2),
('CSC2122', 2, 1, 2),
('CSC2212', 2, 2, 2),
('CSC2222', 2, 2, 2),
('CSC2234', 3, 2, 2),
('CSC3112', 2, 1, 3),
('CSC3123', 2, 1, 3),
('CSC3213', 2, 2, 3),
('CSC3222', 2, 2, 3),
('CSH3143', 2, 2, 3),
('CSH3153', 2, 2, 3),
('CSH3163', 3, 2, 3),
('CSH3242', 2, 2, 3),
('CSH3254', 3, 2, 3),
('CSH3263', 3, 2, 3),
('CSH3273', 3, 2, 3),
('CSH4112', 2, 1, 4),
('CSH4123', 2, 1, 4),
('CSH4133', 3, 1, 4),
('CSH4144', 3, 1, 4),
('CSH4152', 2, 1, 4),
('CSH4162', 2, 1, 4),
('CSH4173', 3, 1, 4),
('EL4112', 2, 1, 4),
('EL4122', 2, 1, 4),
('EL4132', 2, 1, 4),
('EL4142', 2, 1, 4),
('EL4152', 2, 1, 4),
('EL4162', 2, 1, 4),
('EL4172', 2, 1, 4),
('EL4182', 2, 1, 4),
('EL4192', 0, 1, 4),
('IT1113', 2, 1, 1),
('IT1122', 2, 1, 1),
('IT1134', 2, 1, 1),
('IT1144', 2, 1, 1),
('IT1152', 2, 1, 1),
('IT1214', 2, 2, 1),
('IT1223', 2, 2, 1),
('IT1232', 2, 2, 1),
('IT1242', 2, 2, 1),
('IT1252', 1, 2, 1),
('IT1262', 2, 2, 1),
('IT2114', 2, 1, 2),
('IT2122', 2, 1, 2),
('IT2133', 2, 1, 2),
('IT2143', 1, 1, 2),
('IT2153', 2, 1, 2),
('IT2212', 2, 2, 2),
('IT2223', 2, 2, 2),
('IT2234', 2, 2, 2),
('IT2244', 2, 2, 2),
('IT2252', 2, 2, 2),
('IT3113', 2, 1, 3),
('IT3122', 2, 1, 3),
('IT3133', 2, 1, 3),
('IT3143', 2, 1, 3),
('IT3162', 2, 1, 3),
('IT3213', 2, 2, 3),
('IT3223', 2, 2, 3),
('IT3232', 1, 2, 3),
('IT3243', 2, 2, 3),
('IT3252', 2, 2, 3),
('IT3262', 2, 2, 3),
('IT4113', 2, 1, 4),
('IT4123', 2, 1, 4),
('IT4133', 2, 1, 4),
('IT4142', 2, 1, 4),
('IT4153', 2, 1, 4),
('PMA1113', 3, 1, 1),
('PMA1213', 3, 2, 1),
('PMA2113', 3, 1, 2),
('PMA3213', 3, 2, 3),
('STA1113', 3, 1, 1),
('STA1213', 3, 2, 1),
('STA2113', 2, 1, 2),
('STA2213', 3, 2, 2),
('STA3113', 2, 1, 3),
('STA3212', 2, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `ENo` int(11) NOT NULL,
  `EmployeeID` varchar(20) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Actor` varchar(10) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Position` varchar(30) NOT NULL,
  `EmailID` varchar(50) NOT NULL,
  `ProfileImage` blob NOT NULL,
  `Password` varchar(300) NOT NULL,
  `LastLogin` datetime NOT NULL,
  `is_deleted` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`ENo`, `EmployeeID`, `FullName`, `Actor`, `Department`, `Position`, `EmailID`, `ProfileImage`, `Password`, `LastLogin`, `is_deleted`) VALUES
(13, 'ASM/DPS/001', 'Sanmugasundaram Thirukumaran', 'Admin', 'Physical Science', 'L', 'dayaranimsa@gmail.com', '', 'f865b53623b121fd34ee5426c792e5c33af8c227', '2023-09-17 17:49:16', 0),
(10, 'ASM/DPS/002', 'Wathsala Jayamini Kariyapperuma', 'Admin', 'Physical Science', 'AF', 'san545nimanthi@gmail.com', '', '961bfa8a8b5c887c38fab5dbff95bef340bdea37', '2023-05-23 04:57:37', 0),
(14, 'ASM/DPS/003', 'Lakshika Nanthakumaran', 'User', 'Physical Science', 'L', 'abc@gmail.com', '', '418f0210815a04569cc5ec6762e4fede6742260f', '2023-05-22 20:32:14', 0),
(17, 'ASM/DPS/004', 'S. Thirukumaran', 'User', 'Physical Science', 'SLG', 'thirukumaran@vau.ac.lk', '', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '2023-06-13 08:51:16', 0),
(18, 'ASM/DPS/005', 'Wathsala', 'User', 'Bio Science', 'HOD', 'wathsala@gmail.com', '', 'fc1200c7a7aa52109d762a9f005b149abef01479', '2023-06-13 12:15:52', 0),
(19, 'ASM/DPS/010', 'User', 'Admin', 'Physical Science', 'L', 'user@gmail.com', '', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '2023-09-17 17:53:11', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `3rd_year_group_project`
--
ALTER TABLE `3rd_year_group_project`
  ADD PRIMARY KEY (`GPNo`);

--
-- Indexes for table `4th_year_research`
--
ALTER TABLE `4th_year_research`
  ADD PRIMARY KEY (`ResNo`);

--
-- Indexes for table `academicyear`
--
ALTER TABLE `academicyear`
  ADD PRIMARY KEY (`AccNo`);

--
-- Indexes for table `academic_cor`
--
ALTER TABLE `academic_cor`
  ADD PRIMARY KEY (`EmployeeID`,`Academic_year`);

--
-- Indexes for table `academic_instructions_practical_lecture_sessions`
--
ALTER TABLE `academic_instructions_practical_lecture_sessions`
  ADD PRIMARY KEY (`CNo`);

--
-- Indexes for table `academic_instructions_theory_lecture_sessions`
--
ALTER TABLE `academic_instructions_theory_lecture_sessions`
  ADD PRIMARY KEY (`TNo`);

--
-- Indexes for table `computation_results`
--
ALTER TABLE `computation_results`
  ADD PRIMARY KEY (`CRN`);

--
-- Indexes for table `evolution_practical_reports`
--
ALTER TABLE `evolution_practical_reports`
  ADD PRIMARY KEY (`EPR`);

--
-- Indexes for table `evolution_quiz_assignments_tutorials`
--
ALTER TABLE `evolution_quiz_assignments_tutorials`
  ADD PRIMARY KEY (`EQN`);

--
-- Indexes for table `intern_supervision`
--
ALTER TABLE `intern_supervision`
  ADD PRIMARY KEY (`InNo`);

--
-- Indexes for table `marking_exam_papers`
--
ALTER TABLE `marking_exam_papers`
  ADD PRIMARY KEY (`Mex`);

--
-- Indexes for table `marking_exam_papersp`
--
ALTER TABLE `marking_exam_papersp`
  ADD PRIMARY KEY (`Mex`);

--
-- Indexes for table `moderating_exam_papers`
--
ALTER TABLE `moderating_exam_papers`
  ADD PRIMARY KEY (`MEN`);

--
-- Indexes for table `moderating_exam_papersp`
--
ALTER TABLE `moderating_exam_papersp`
  ADD PRIMARY KEY (`MEN`);

--
-- Indexes for table `practical_field_visits`
--
ALTER TABLE `practical_field_visits`
  ADD PRIMARY KEY (`FNo`);

--
-- Indexes for table `practical_subjects`
--
ALTER TABLE `practical_subjects`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `practical_viva_sessions`
--
ALTER TABLE `practical_viva_sessions`
  ADD PRIMARY KEY (`PV_No`);

--
-- Indexes for table `research_supervision`
--
ALTER TABLE `research_supervision`
  ADD PRIMARY KEY (`EmployeeID`,`Academic_year`);

--
-- Indexes for table `seminar_course`
--
ALTER TABLE `seminar_course`
  ADD PRIMARY KEY (`SC_No`);

--
-- Indexes for table `setting_exam_papers`
--
ALTER TABLE `setting_exam_papers`
  ADD PRIMARY KEY (`SPN`);

--
-- Indexes for table `setting_exam_papers_practical`
--
ALTER TABLE `setting_exam_papers_practical`
  ADD PRIMARY KEY (`SPN`);

--
-- Indexes for table `theory_subjects`
--
ALTER TABLE `theory_subjects`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`EmployeeID`),
  ADD KEY `ENo` (`ENo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `3rd_year_group_project`
--
ALTER TABLE `3rd_year_group_project`
  MODIFY `GPNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `4th_year_research`
--
ALTER TABLE `4th_year_research`
  MODIFY `ResNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `academicyear`
--
ALTER TABLE `academicyear`
  MODIFY `AccNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `academic_instructions_practical_lecture_sessions`
--
ALTER TABLE `academic_instructions_practical_lecture_sessions`
  MODIFY `CNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `academic_instructions_theory_lecture_sessions`
--
ALTER TABLE `academic_instructions_theory_lecture_sessions`
  MODIFY `TNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `computation_results`
--
ALTER TABLE `computation_results`
  MODIFY `CRN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `evolution_practical_reports`
--
ALTER TABLE `evolution_practical_reports`
  MODIFY `EPR` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `evolution_quiz_assignments_tutorials`
--
ALTER TABLE `evolution_quiz_assignments_tutorials`
  MODIFY `EQN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `intern_supervision`
--
ALTER TABLE `intern_supervision`
  MODIFY `InNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `marking_exam_papers`
--
ALTER TABLE `marking_exam_papers`
  MODIFY `Mex` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `marking_exam_papersp`
--
ALTER TABLE `marking_exam_papersp`
  MODIFY `Mex` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `moderating_exam_papers`
--
ALTER TABLE `moderating_exam_papers`
  MODIFY `MEN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `moderating_exam_papersp`
--
ALTER TABLE `moderating_exam_papersp`
  MODIFY `MEN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `practical_field_visits`
--
ALTER TABLE `practical_field_visits`
  MODIFY `FNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `practical_viva_sessions`
--
ALTER TABLE `practical_viva_sessions`
  MODIFY `PV_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `seminar_course`
--
ALTER TABLE `seminar_course`
  MODIFY `SC_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting_exam_papers`
--
ALTER TABLE `setting_exam_papers`
  MODIFY `SPN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `setting_exam_papers_practical`
--
ALTER TABLE `setting_exam_papers_practical`
  MODIFY `SPN` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `ENo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
